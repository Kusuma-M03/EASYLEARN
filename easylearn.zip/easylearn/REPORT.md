# EasyLearn: A Generative AI Accessibility Assistant for Students with Learning Difficulties

**Course:** RTD Open Elective  |  **Name / USN:** ____________  |  **Guide:** Dr. Santosh Kumar J.
School of Engineering, Dayananda Sagar University

## 1. Problem Statement
Students with dyslexia, ADHD, low vision or limited English proficiency struggle with dense academic text. Teachers rarely have time to prepare adapted material for every learner. In India this is compounded by the fact that most study material is in English while many students are more comfortable in Kannada or Hindi.

## 2. Objectives
1. Automatically simplify study material to a chosen reading level.
2. Adapt the output style to the learner's profile.
3. Provide multimodal access (text, audio) in English, Kannada and Hindi.
4. Measure the improvement using readability metrics.

## 3. Generative AI Concepts Used
| Concept | Where used |
|---|---|
| Large Language Models (Llama 3.3 via Groq / Gemini) | All text transformation |
| Prompt engineering (role, constraints, persona, output format) | `core/prompts.py` |
| Controlled text simplification | Level + profile conditioned prompts |
| Summarization | Key points, audio script |
| Multilingual generation | English / Kannada / Hindi output |
| Chunking (map-style processing) | Long documents split at paragraph boundaries |
| Guardrails | System prompt forbids adding facts; UI verification warning |

## 4. System Architecture
```
Upload PDF/TXT/paste -> Extract (PyMuPDF) -> Clean -> Chunk (<=1000 words)
   -> LLM simplify (level + profile + language) -> merge
   -> on demand: key points | glossary | steps | audio script | quiz
   -> gTTS audio | readability metrics | download
```
Frontend: Streamlit. Backend: Python modules in `core/`. Provider abstraction allows Groq or Gemini.

## 5. Implementation Summary
- **Extraction and cleaning:** removes hyphenation and line-wrap artefacts so the LLM sees clean text.
- **Prompts:** every prompt carries the reading-level description, the learner-profile rule and the language instruction. The system prompt requires preserving numbers, names and formulas.
- **Reliability:** retries with exponential backoff; derived outputs are generated lazily to save API quota.
- **Accessibility UI:** Lexend font (designed for readability), high-contrast theme, adjustable size and spacing.

## 6. Results
Run the app on the sample photosynthesis text and fill this table from the Readability tab:

| Metric | Original | Simplified (Grade 5) |
|---|---|---|
| Avg sentence length | ___ | ___ |
| Flesch Reading Ease | ___ | ___ |
| Flesch-Kincaid Grade | ___ | ___ |

*Insert screenshots: home page, simplified output, glossary, audio tab, readability table, Kannada output.*

## 7. Testing
Unit tests cover cleaning, chunking, markdown stripping and readability direction (4 tests, all passing). Manual tests: PDF, TXT, pasted text, each language, each profile.

## 8. Limitations
- Possible hallucination or loss of nuance when simplifying.
- Kannada/Hindi quality varies and was reviewed only informally.
- No OCR for scanned PDFs; readability metrics only for English.
- Free API tiers have rate limits; gTTS needs internet.

## 9. Ethical Considerations
- **Accuracy:** the app shows a "verify with the original" warning; simplified text is an aid, not a replacement.
- **Privacy:** text is sent to a third-party API; users are warned not to upload confidential documents, and no data is stored by the app.
- **Bias and fairness:** simplification can drop culturally specific content; human review is recommended.
- **Inclusion:** not a diagnostic tool; it does not label users, it only adapts presentation.

## 10. Future Work
OCR for scanned notes, local/offline models, speech input, per-user progress tracking, teacher dashboard, human evaluation with real students.

## 11. Conclusion
EasyLearn shows how LLMs can make education more inclusive by personalising text for learners' needs, languages and reading levels, using only free tools.

## References
Streamlit docs; Groq API docs; Google Gemini API docs; PyMuPDF; gTTS; textstat; Flesch (1948) Reading Ease formula; Kincaid et al. (1975).
